=== Newspack Theme ===
Contributors: Automattic
Tags:
Requires at least: 4.9.6
Tested up to: WordPress 5.0
Stable tag: 1.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

The theme for Newspack. https://newspack.blog.

== Description ==

== Changelog ==

= 1.0 =
*

Initial release

== Resources ==
* Twenty Nineteen, © 2018-2019 WordPress, GNU GPL v2 or later
* normalize.css, © 2012-2018 Nicolas Gallagher and Jonathan Neal, MIT
* Underscores, © 2012-2018 Automattic, Inc., GNU GPL v2 or later
